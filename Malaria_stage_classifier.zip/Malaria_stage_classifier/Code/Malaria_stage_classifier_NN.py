"""
Python script for NN training.

This script reads text files of characteristic cuts and trains a neural network for 20 epochs.
The network is then saved.

"""

# libraries
import os
from PIL import Image
import cv2
import random
import numpy as np
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import shutil
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.optimizers import RMSprop

def format_NN_values(name, spath):
    """Formats values for NN input and writes them into array

    Parameters
        ----------
    name : str
        Name of the txt file
    spath : str
        Name of the directory
    parameter : str
        Name of the parameter

    Returns
    -------
    array
        an array with type float that contains the content of the txt file

    """
    values = []
    # reads x_data from folder
    data = open(spath + '/' + name,'r')
    row = data.read().split('\n')
    col = row[0].split(' ') 
    nrow = len(row)
    ncol = len(col)
    data.close()
    # writes x_data in array
    v = []
    for cs in row:
        num = cs.split(' ')
        for n in num:
            #print(n)
            if len(n) == 0:
                continue
            elif len(n) == 1:
                if n[-1] == ']':
                    values.append(v)
                    v = []
            else:
                try:
                    if n[0] == '[' and n[1] == '[':
                        try:
                            v.append(float(n.replace('[[', '')))
                        except ValueError:
                            continue
                    elif n[0] == '[':
                        v.append(float(n.replace('[', '')))
                    elif n[-1] == ']' and n[-2] == ']':
                        n.replace(' ', '')
                        try:
                            v.append(float(n.replace(']]', '')))
                        except ValueError or IndexError:
                            continue
                    elif n[-1] == ']':
                        if len(n) == 1:
                            values.append(v)
                        else:
                            n.replace(' ', '')
                            v.append(float(n.replace(']', '')))
                            values.append(v)
                        v = []
                    else:
                        try:
                            v.append(float(n))
                        except ValueError:
                            continue
                except IndexError:
                    continue
    if len(v) > 0:
        values.append(v)
    return values

def train_model(model, carr_form, label_form, cut_train, label_train, directory, mname):
    """Trains NN model on a combination of old and new data
    
    Parameters
    ----------
    model : Sequential
        The pre-trained neural network
    carr_form : ndarray
        N x 2 x 50 array with type float that contains N times two characteristic cross-sections with 50 data points
    label_form : ndarray
        N x 1 array with type int that contains the labels of N cells
    directory : str
        The name of the network folder
    mname : str
        The name of the new network
        
    Returns
    -------
    model : tf.keras.Sequential
        tf.keras.Sequential that contains the trained new keras model
        
    """
    # Formats the input data and target labels
    cut_new = carr_form.reshape(carr_form.shape[0], carr_form.shape[2], carr_form.shape[1])
    label_new = to_categorical(label_form, num_classes=4)
    # Formats the old data
    cut_train = np.asarray(cut_train)
    cut_old = cut_train.reshape(cut_train.shape[0], cut_train.shape[2], cut_train.shape[1])
    label_old = to_categorical(label_train, num_classes=4)
    # Updates model with a smaller learning rate
    opt = RMSprop(learning_rate=0.0001)
    # Compiles the model
    model.compile(optimizer=opt, loss='categorical_crossentropy')
    # Creates a composite dataset of old and new data
    cut, label = np.vstack((cut_old, cut_new)), np.vstack((label_old, label_new))
    # Fits the model on new data
    model.fit(cut, label, epochs=20, batch_size=20, shuffle=True, verbose = 2)
    # Saves the new model
    model.save(directory + '/' + mname + '.h5')  
    return model
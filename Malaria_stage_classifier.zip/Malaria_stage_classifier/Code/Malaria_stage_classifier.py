# libraries
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter.filedialog import askopenfilename, asksaveasfilename
from webbrowser import open_new
import sys
import os
import traceback
import numpy as np
from scipy import ndimage
import skimage.draw
from skimage import filters
import csv
from tensorflow.keras.models import load_model
import tensorflow as tf
from pathlib import Path
from copy import copy

# scripts
from Malaria_stage_classifier_classes import * 
from Malaria_stage_classifier_extractCuts import *
from Malaria_stage_classifier_contours import *
from Malaria_stage_classifier_NN import *

# for error logging
import logging
tf.get_logger().setLevel(logging.ERROR)

# main program
class CellDet(tk.Tk):
    def __init__(self):
        super().__init__()
        self.initialise()
        
    def initialise(self):
        self.title("Classification of RBCs with characteristic cuts")
        self.resizable(False, False)

        self.style = ttk.Style()
        self.style.configure("TLabelframe", padding=5, borderwidth=3)
        
        #----------------------------------------------------------------------------------Menu
        self.menubar = tk.Menu(self)
        self.config(menu=self.menubar)

        file = tk.Menu(self.menubar, tearoff=0)
        file.add_command(label="Exit", command=self.destroy)
        self.menubar.add_cascade(label="File", menu=file)

        about = tk.Menu(self.menubar, tearoff=0)
        about.add_command(label="About program", command=self.about_program_window)
        self.menubar.add_cascade(label="Help", menu=about)
        
        # sets all frames and labels
        #------------------------------------Variable and Frame declaration
        self.input_path_and_filename = tk.StringVar()
        self.input_type = tk.StringVar()
        self.meth = tk.StringVar()
        self.HCvar = tk.IntVar()
        self.enhvar = tk.IntVar()
        self.output_filename = tk.StringVar()
        self.output_filetype = tk.StringVar()
        # determines, if the program has been run before
        self.reload = 0
        self.read = 0
        self.found = 0
        self.save_pred = 0
        # gets current file path
        path = Path(sys.path[0])
        self.fdrc = str(path.parent)
        # sets variables for reference
        self.contact = "katharina.preissinger@physik.uni-augsburg.de"
        self.reference = ""
        self.doc = "https://stage-specific-classification-of-rbc.readthedocs.io/en/latest/index.html#"
        self.article_link = ""
        self.software_page = ("https://github.com/KatharinaPreissinger/Stage_specific_classification_of_RBCs/" +
                              "tree/master/Code")
        self.github_repository = "https://github.com/KatharinaPreissinger/Stage_specific_classification_of_RBCs"
        self.NN_data = "https://zenodo.org/record/6866337"

        # sets all variables to default at start
        self.input_type.set("")
        self.input_path_and_filename.set("")
        self.meth.set("")
        self.HCvar.set(0)
        self.enhvar.set(0)
        self.output_filename.set("")
        self.output_filetype.set("csv")
        self.var_version = "1.0"
        
        # creates tabs for evaluation
        self.tab_parent = ttk.Notebook(self)

        self.setup = ttk.Frame(self.tab_parent)
        self.rawimg = ttk.Frame(self.tab_parent)
        self.thresimg = ttk.Frame(self.tab_parent)
        self.selst = ttk.Frame(self.tab_parent)
        self.classify = ttk.Frame(self.tab_parent)

        self.tab_parent.add(self.setup, text="Settings")
        self.tab_parent.add(self.rawimg, text="Show image")
        self.tab_parent.add(self.thresimg, text="Threshold image")
        self.tab_parent.add(self.selst, text="Detect cells")
        self.tab_parent.add(self.classify, text="Classify cells")
        self.tab_parent.tab(self.setup, state="normal")
        self.tab_parent.tab(self.rawimg, state="disabled")
        self.tab_parent.tab(self.thresimg, state="disabled")
        self.tab_parent.tab(self.selst, state="disabled")
        self.tab_parent.tab(self.classify, state="disabled")
        # bind action to notebook
        self.tab_parent.bind('<<NotebookTabChanged>>', self.tab_action)
        
        # first tab
        
        # first row: input file
        self.input_filename_Frame = ttk.LabelFrame(self.setup, text="Open file")
        self.input_filename_Frame.grid(row=0, column=0, columnspan=2, sticky="NW", padx=15, pady=5)
        ttk.Button(self.input_filename_Frame, text="Select file (.txt, .tif, .bmp or .png)",
                   command=self.select_file).grid(row=0, column=0, sticky="W", padx=(0, 10))
        self.filename_label = ttk.Label(self.input_filename_Frame, text="Please select file.")
        self.filename_label.grid(row=0, column=1, columnspan=1, sticky="W")
        
        # second row: input type and threshold entry
        self.input_type_Frame = ttk.LabelFrame(self.setup, text="Select file type")
        self.input_type_Frame.grid(row=1, column=0, columnspan=3, sticky="NW", padx=15, pady=5)
        
        # third row: imaging methods
        self.img_meth_Frame = ttk.LabelFrame(self.setup, text="Imaging method")
        self.img_meth_Frame.grid(row=2, column=0, columnspan=3, sticky="NW", padx=15)
        
        # fourth row: output file
        self.output_filename_Frame = ttk.LabelFrame(self.setup, text="Save file")
        self.output_filename_Frame.grid(row=4, column=0, columnspan=2, rowspan=3, sticky="NW", padx=15, pady=5)
        ttk.Button(self.output_filename_Frame, text="Save file",
                   command=self.save_file).grid(row=0, column=0, sticky="NW", padx=(0, 10), pady=(0, 5))
        self.output_file_label = ttk.Label(self.output_filename_Frame, text="No file selected.")
        self.output_file_label.grid(row=0, column=1, sticky="W", pady=(0,5))
        
        # second tab
        
        # Only image: see select_file
        self.read_image_Frame = ttk.LabelFrame(self.rawimg, text="Read image")
        self.read_image_Frame.grid(row=0, column=0, sticky="N")
        
        # third tab
        
        # threshold
        self.threshold_Frame = ttk.LabelFrame(self.thresimg, text="Choose threshold value:")
        
        # fourth tab
                
        # Detects cells
        self.hough_circ_Frame = ttk.LabelFrame(self.selst, text="Detect cells")
        self.hough_circ_Frame.grid(row=0, column=1, sticky="NW")
        # Creates checkboxes
        self.defHC = ttk.Checkbutton(self.hough_circ_Frame, variable=self.HCvar, command=self.setHC_to_default)
        self.defHC.grid(row=6, column=2, sticky="NW")
        self.defHCl = ttk.Label(self.hough_circ_Frame, text='Default')
        self.defHCl.grid(row=6, column=1, sticky="NW")
        self.enh = ttk.Checkbutton(self.hough_circ_Frame, variable=self.enhvar,
                                   command=self.enh_imageHC)
        self.enh.grid(row=7, column=2, sticky="NW")
        self.enhl = ttk.Label(self.hough_circ_Frame, text='Enhance contrast')
        self.enhl.grid(row=7, column=1, sticky="NW")
        # shows info 
        self.info_dc = ttk.LabelFrame(self.selst, text="Notes")
        self.info_dc.grid(row=1, column=1, sticky="NW")
        self.status_dc = tk.Label(self.info_dc, text="")
        self.status_dc.grid(row=0, column=0, sticky="NW")
    
        # fifth tab
        
        # Run NN
        self.NN_Frame = ttk.LabelFrame(self.classify, text="Classify cells")
        self.NN_Frame.grid(row=0, column=0, sticky="NW")
        # load NN for respective method -> folder
        self.load = ttk.Button(self.NN_Frame, text='Load NN',
                               command=self.load_NN)
        self.load.grid(row=0, column=0, sticky="NW", padx=(0, 10))
        # classify each cell -> use cell object with 2 cuts and set label by NN
        self.predict = ttk.Button(self.NN_Frame, text='Predict stages',
                                  command=self.predict_stages)
        self.predict.grid(row=1, column=0, sticky="NW", padx=(0, 10))
        self.predict["state"] = "disabled"
        # draw image with coloured circles according to label
        # enable user to change labels
        self.cpred = ttk.Button(self.NN_Frame, text='Change predictions',
                                command=self.change_Circle_predictions)
        self.cpred.grid(row=2, column=0, sticky="NW", padx=(0, 10))
        self.cpred["state"] = "disabled"
        # saves characteristic cross-sections to new NN folder for training
        self.addData = ttk.Button(self.NN_Frame, text='Add data to NN',
                                  command=self.addData_NN)
        self.addData.grid(row=3, column=0, sticky="NW", padx=(0,10))
        self.addData["state"] = "disabled"
        # on button click: write all data into .csv file
        self.save = ttk.Button(self.NN_Frame, text='Save predictions',
                               command=self.save_predictions)
        self.save.grid(row=4, column=0, sticky="NW", padx=(0, 10))
        self.save["state"] = "disabled"
        # legend for the cell classification
        self.legend = ttk.LabelFrame(self.classify, text="Legend")
        self.legend.grid(row=1, column=0, sticky="NW")
        self.hlegend = tk.Label(self.legend, text='Healthy cell = ')
        self.hlegend.grid(row=0, column=0, sticky="NW")
        self.rlegend = tk.Label(self.legend, text='Ring stage = ')
        self.rlegend.grid(row=1, column=0, sticky="NW")
        self.tlegend = tk.Label(self.legend, text='Trophozoite stage = ')
        self.tlegend.grid(row=2, column=0, sticky="NW")
        self.slegend = tk.Label(self.legend, text='Schizont stage = ')
        self.slegend.grid(row=3, column=0, sticky="NW")
        self.nclegend = tk.Label(self.legend, text='No cell = ')
        self.nclegend.grid(row=4, column=0, sticky="NW")
        self.hcolour = tk.Label(self.legend, text='lightblue', fg='deepskyblue')
        self.hcolour.grid(row=0, column=1, sticky="NW")
        self.rcolour = tk.Label(self.legend, text='blue', fg = 'blue')
        self.rcolour.grid(row=1, column=1, sticky="NW")
        self.tcolour = tk.Label(self.legend, text='yellow', fg = 'yellow', bg = 'black')
        self.tcolour.grid(row=2, column=1, sticky="NW")
        self.scolour = tk.Label(self.legend, text='lime', fg = 'lime')
        self.scolour.grid(row=3, column=1, sticky="NW")
        self.nccolour = tk.Label(self.legend, text='magenta', fg = 'magenta')
        self.nccolour.grid(row=4, column=1, sticky="NW")
        # notes for buttons
        self.notesNN = ttk.LabelFrame(self.classify, text="Notes")
        self.notesNN.grid(row=2, column=0, sticky="NW")
        self.message = tk.Label(self.notesNN, text="")
        self.message.grid(row=0, column=0, sticky="NW")
        
        self.tab_parent.pack(expand=1, fill='both')
       
    # getting path of images
    def get_path(self, relative_path):
        """Gets path from openfile dialog
        
        """
        if hasattr(sys, '_MEIPASS'):
            return os.path.join(sys._MEIPASS, relative_path) # pylint: disable=no-member
        return os.path.join(os.path.abspath("."), relative_path)  

    #-----------------------------------------------Helper functions
    
    def tab_action(self, event):
        """Selects actions based on tab name
        
        """
        selected_tab = event.widget.select()
        tab_text = event.widget.tab(selected_tab, "text")
        if tab_text == "Show image":
            if self.read == 0:
                self.read_image()
                self.read = 1
        elif tab_text == "Detect cells":
            if self.found == 0:
                self.find_cells()
                self.found = 1

    def update_filename_label(self, filename, label, char_limit):
        """Updates the label of the output and input file
        
        """
        if label == self.filename_label:
            filename_no_ext = filename[:filename.rfind(".")]
            if len(filename_no_ext) > char_limit:
                label_text = filename_no_ext[:char_limit] + "[...]" + filename[filename.rfind("."):]
            else:
                label_text = filename
            self.filename_label.config(text=label_text)
        elif label == self.output_file_label:
            if len(filename) > char_limit:
                label_text = filename[:char_limit] + "[...]"
            else:
                label_text = filename
            self.output_filename_entry = ttk.Entry(self.output_filename_Frame, width=70)
            self.output_filename_entry.grid(row=0, column=1, sticky="W", pady=(0,5))
            self.output_filename_entry.insert(0, label_text)
            self.var_output_filename = label_text
            label.config(text="")
        self.parameters_set()

    #-----------------------------------------------------Layout control
    def remove_frames(self, frames_list):
        """Removes frames from layout
        
        """
        for frame in frames_list:
            frame.grid_remove()
            
    def input_type_frames_layout(self):
        """Sets the layout for the radiobutton
        
        """
        frames_list = [self.threshold_Frame]
        self.remove_frames(frames_list)
        
        self.var_input_type = self.input_type.get()
        if self.input_type.get() == "txt":
            # Sets number of header lines in txt file
            self.format_txt_Frame = ttk.LabelFrame(self.input_type_Frame)
            self.format_txt_Frame.grid(row=1, column=0, columnspan=2)
            self.fform_label = ttk.Label(self.format_txt_Frame, text="Set number of header lines in text file:")
            self.fform_label.grid(row=0, column=0, columnspan=2)
            self.fform = ttk.Entry(self.format_txt_Frame, width=6)
            self.fform.insert(END, '3')
            self.fform.grid(row=1, column=0)
            self.setff = ttk.Button(self.format_txt_Frame, text="Set file format", command=self.set_file_format)
            self.setff.grid(row=1, column=1, sticky="W", padx=(0, 10))
            self.stat_format = ttk.Label(self.format_txt_Frame, text="")
            self.stat_format.grid(row=1, column=2, sticky="NW", padx=(0,10))
            # Sets the threshold frame
            self.threshold_Frame.grid(row=0, column=0, columnspan=2, sticky="NW", padx=15)
        else:
            try:
                self.format_txt_Frame.grid_forget()
            except AttributeError:
                forget = 1
            
    def parameters_set(self):
        """Checks, if all parameters in the first tab have been set
        
        """
        if  (self.input_path_and_filename.get() == "" or self.input_type.get() == ""
             or self.output_filename.get() == ""): # or self.output_filetype.get() == ""):
            self.tab_parent.tab(self.rawimg, state="disabled")
        else:
            self.tab_parent.tab(self.rawimg, state="normal")
        
    def img_meth_frames_layout(self, event):
        frames_list = []
        self.remove_frames(frames_list)
        if self.meth.get() == "AFM":
            # enable tab
            self.var_meth = self.meth.get()
            self.thresimg_enable = 1
        elif self.meth.get() == "Fluorescence microscopy":
            self.var_meth = self.meth.get()
            self.thresimg_enable = 0
        elif self.meth.get() == "Light microscopy":
            self.var_meth = self.meth.get()
            self.thresimg_enable = 0
        
    #---------------------------------------------------------------GUI Content   
    
    # Creates image from raw data 
    def create_newdir(self, directory, name):
        """Creates new directory

        Parameters
        ----------
        directory : str
            The directory of the new folder
        name : str
            The name of the new folder

        Returns
        -------
        str
            The directory + name of the new folder

        """
        drc = directory + '/' + name
        if not os.path.exists(drc):
            os.makedirs(drc)
        return drc

    #Input file button & label
    def select_file(self):
        """Enables the user to select a file and extracts data from text files or image files
        
        """
        if self.save_pred == 0 and self.read == 1:
            self.load_win()
        else:
            msplit = self.get_path("").split('\\')
            '''
            dro = ''
            for i in range(0, len(msplit) - 3):
                dro += msplit[i] + '/'
            dir_open = dro + msplit[i + 1]'''
            # sys.path to get the running directory
            # create saved_file, if it does not exist
            # if not, open another directory
            dir_open = Path(sys.path[0]).parent
            path_and_filename = askopenfilename(initialdir = dir_open, title="Select file (.txt or .png)",
                                                filetypes=(("Data files",".txt .png .tif .bmp"),("All files","*.*")))
            if (path_and_filename.endswith(".txt") or path_and_filename.endswith(".png") or
                path_and_filename.endswith(".tif") or path_and_filename.endswith(".bmp")):
                try:
                    self.update_filename_label(filename = path_and_filename[path_and_filename.rfind("/")+1:],
                                               label = self.filename_label, char_limit=50)
                    self.var_input_path_and_filename = path_and_filename
                    self.input_path_and_filename.set(path_and_filename)

                except Exception as error_msg:
                    messagebox.showerror("Error!", error_msg)

            elif path_and_filename != "":
                messagebox.showerror("Error!", "Please select a valid .txt or .png file.")

            # Input Type
            input_type_Dict = {"Text file" : "txt", "Image file" : "img"}
            itype = 0
            if (path_and_filename.endswith(".png") or path_and_filename.endswith(".tif")
                or path_and_filename.endswith(".bmp")):
                self.input_type.set("img")
            elif path_and_filename.endswith(".txt"):
                self.input_type.set("txt")
                self.input_type_frames_layout()
            for (text, value) in input_type_Dict.items(): 
                    ttk.Radiobutton(self.input_type_Frame, text=text, variable=self.input_type, value=value,
                                    command=self.input_type_frames_layout).grid(row=0, column=itype, sticky="W")
                    itype += 1

            # Choose imaging method
            meth_options = ("AFM", "Fluorescence microscopy", "Light microscopy")
            self.meth_drop = ttk.Combobox(self.img_meth_Frame, values=meth_options, state="readonly", width=30,
            textvariable=self.meth)
            self.meth_drop.bind("<<ComboboxSelected>>", self.img_meth_frames_layout)
            self.meth_drop.grid(row=0, column=0)
            # Enter threshold value
            self.thres = ttk.Entry(self.threshold_Frame, width=8)
            self.thres.grid(row=0, column=0)
            ttk.Button(self.threshold_Frame, text="Set threshold",
                       command=self.get_thres_entry).grid(row=0, column=1, sticky="NW", padx=(0, 10))
        
    def set_file_format(self):
        """Sets number of header lines of txt file
        
        """
        self.hlines = self.fform.get()
        self.stat_format.config(text="File format is set.")
            
    # Output file button & label
    def save_file(self):
        """Sets the output filename and the format
        
        """
        dir_s = str(Path(sys.path[0]).parent)
        dir_save = self.create_newdir(dir_s, 'Saved_files')
        filename = asksaveasfilename(initialdir = dir_save, title = "Save output file...",
                                     filetypes = (("All files","*.*"), ("Text files", ".txt")))

        if filename != "":
            self.output_filename.set(filename)
            self.update_filename_label(filename=filename, label=self.output_file_label, char_limit=len(filename))
            # text file
            self.drc = Path(filename).parent
            self.prefix = Path(filename).stem
            self.directory = self.create_newdir(str(self.drc), str(self.prefix))
            self.output_filetype_drop = ttk.Combobox(self.output_filename_Frame, values=("csv",  "txt"),
                                                     state="readonly", width=10, textvariable=self.output_filetype)
            self.output_filetype_drop.grid(row=1, column=1, sticky="W")
             # reads info icon
            from PIL import Image, ImageTk
            info_icon = Image.open(self.fdrc + '/' + 'Logo/' + "info_icon.png")
            icon = info_icon.resize((15,15))
            self.info_icon = ImageTk.PhotoImage(icon) 
            # info for classification
            self.iload = ttk.Label(self.NN_Frame, image=self.info_icon)
            self.iload.grid(row=0, column=1)
            ToolTip(widget = self.iload, text = "Loads the pretrained neural Network.")
            self.ipredict = ttk.Label(self.NN_Frame, image=self.info_icon)
            self.ipredict.grid(row=1, column=1)
            ToolTip(widget = self.ipredict, text = "Predicts the stage for each detected cell.")
            self.icpred = ttk.Label(self.NN_Frame, image=self.info_icon)
            self.icpred.grid(row=2, column=1)
            ToolTip(widget = self.icpred, text = "To change the predictions, please click inside the cell.")
            self.trainNN = ttk.Label(self.NN_Frame, image=self.info_icon)
            self.trainNN.grid(row=3, column=1)
            ToolTip(widget = self.trainNN, text = "Adds new data to and retrains the neural network.")
            self.isave = ttk.Label(self.NN_Frame, image=self.info_icon)
            self.isave.grid(row=4, column=1)
            ToolTip(widget = self.isave, text = "Saves the prediction in the selected file format.")
            
    #---------------------------------------------------------------Show image
    
    def format_file(self, filename, info):
        """Reads raw .txt file and counts number of rows and columns

        Parameters
        ----------
        filename : str
            The directory + name of the raw .txt file
        info : int
            Number of rows to be skipped 

        Returns
        -------
        list, list, int, int
           list (row) : a list of strings that are the z values of the igor pro data 
           list (col) : a list of strings that are the associated y values
           int (ncol) : an integer that is the number of columns in the .txt file
           int (nrow) : an integer that is the number of rows in the .txt file

        """
        values = open(filename,'r') 
        row = values.read().split('\n')
        col = row[1].split(' ')
        nrow = len(row) - int(info) # drei Zeilen mit Dateiinfo info = 3
        ncol = len(col)
        values.close()
        return row, col, ncol, nrow

    def write_x(self, values, col, nrow, ncol):
        """Writes x values of the igor pro data as float into an array

        Parameters
        ----------
        values : ndarray
            Nrow x ncol dimensional empty array containing data with type float
        col : ndarray
            Nrow x ncol dimensional array ocontaining data with type string
        nrow : int
            The number of rows in the .txt file
        ncol : int
            The number of columns in the .txt file

        Returns
        -------
        array
           an array with type float that contains the x values of the igor pro data

        """
        for i in range(0, ncol):
            for j in range(0, nrow):
                values[j][i] = col[j]
        return values

    def write_x_file(self, directory, filename, nrow, values):
        """Writes x values of the igor pro data in .txt file

        Parameters
        ----------
        directory: str
            The directory where the .txt file is saved
        filename: str
            The directory + name of the raw .txt file
        nrow : int
            The number of rows in the .txt file
        values : ndarray
            Nrow x ncol dimensional array containing data with type float

        """
        dsplit = directory.split('/')
        values_out = open(directory + '/' + dsplit[-1] + '_x_values' + '.txt', "w")
        for i in range(0, nrow):
            values_out.write(str(values[i][0]) + '\n')
        values_out.close()

    def write_y(self, values, col, nrow, ncol):
        """Writes y values of the igor pro data as float into an array

        Parameters
        ----------
        values : ndarray
            Nrow x ncol dimensional empty array containing data with type float
        col : ndarray
            Nrow x ncol dimensional array containing data with type string
        nrow : int
            The number of rows in the .txt file
        ncol : int
            The number of columns in the .txt file

        Returns
        -------
        array
           an array with type float that contains the y values of the igor pro data

        """
        for i in range(0, nrow):
            for j in range(0, ncol):
                values[i][j] = col[j]
        return values

    def write_y_file(self, directory, filename, ncol, values):
        """Writes y values of the igor pro data in .txt file

        Parameters
        ----------
        directory: str
            The directory where the .txt file is saved
        filename: str
            The directory + name of the raw .txt file
        ncol : int
            The number of columns in the .txt file
        values : ndarray
            Nrow x ncol dimensional array containing data with type float

        """
        dsplit = directory.split('/')
        values_out = open(directory + '/' + dsplit[-1] + '_y_values' + '.txt', "w")
        for i in range(0, ncol):
            values_out.write(str(values[0][i]) + '\n')
        values_out.close()

    def write_z(self, values, row, nrow, ncol):
        """Writes z values of the igor pro data as float into an array

        Parameters
        ----------
        values : ndarray
            Nrow x ncol dimensional empty array containing data with type float
        row : ndarray
            Nrow x ncol dimensional array containing data with type string
        nrow : int
            The number of rows in the .txt file
        ncol : int
            The number of columns in the .txt file

        Returns
        -------
        array
           an array with type float that contains the z values of the igor pro data

        """
        for i in range(2, nrow + 2):
            z_values = row[i].split(' ')
            for j in range(0, ncol):
                values[i-2][j] = z_values[j]
        return values

    def write_z_file(self, directory, filename, nrow, ncol, values):
        """Writes z values of the igor pro data in .txt file

        Parameters
        ----------
        directory: str
            The directory where the .txt file is saved
        filename: str
            The directory + name of the raw .txt file
        nrow : int
            The number of rows in the .txt file
        ncol : int
            The number of columns in the .txt file
        values : ndarray
            Nrow x ncol dimensional array containing data with type float

        """
        dsplit = directory.split('/')
        values_out = open(directory + '/' + dsplit[-1] + '_height_trace' + '.txt', "w")       
        for i in range(0, nrow):
            for j in range(0, ncol):
                values_out.write(str(values[i][j]) + '\t')
            values_out.write('\n')
        values_out.close()   
        
    def get_values(self, row, col, ncol, nrow, directory, filename):
        """Generates x, y, z values from the igor pro data

        Parameters
        ----------
        row : ndarray
            Nrow x ncol dimensional array containing data with type stringdetect
        col : ndarray
            Nrow x ncol dimensional array containing data with type string
        nrow : int
            The number of rows in the .txt file
        ncol : int
            The number of columns in the .txt file
        directory: str
            The directory where the .txt file is saved
        filename : str
            The directory + name of the raw .txt file

        Returns
        -------
        array, array, array
           array (x_values) : an array with type float that contains the x values of the igor pro data
           array (y_values) : an array with type float that contains the y values of the igor pro data
           array (z_values) : an array with type float that contains the z values of the igor pro data

        """
        # Generates empty arrays
        z_values = np.zeros(shape=(nrow,ncol))
        x_values = np.zeros(shape=(nrow,ncol))
        y_values = np.zeros(shape=(nrow,ncol))

        # Writes y values in array
        y_values = self.write_y(y_values, col, nrow, ncol) 

        # Generates x values from array of y values
        y_max = np.max(y_values)
        y_min = np.min(y_values)
        stepy = (y_max - y_min)/ncol        
        x_values_gen = np.arange(y_min, (nrow) * stepy + y_min, stepy)

        # Writes x values in array
        x_values = self.write_x(x_values, x_values_gen, nrow, ncol)

        # Saves x values and y values as .txt file
        valdir = self.create_newdir(directory, 'raw_values')
        self.write_y_file(valdir, filename, ncol, y_values)
        self.write_x_file(valdir, filename, nrow, x_values)

        # Writes z values in array
        self.write_z(z_values, row, nrow, ncol)

        # Saves z values as .txt file 
        self.write_z_file(valdir, filename, nrow, ncol, z_values)

        return x_values, y_values, z_values
        
    def plot_afmimg(self, xvalues, yvalues, zvalues, directory):
        """Plots igor pro data as .png image

        Parameters
        ----------
        x : ndarray
            Nrow x ncol dimensional array with type float
        y : ndarray
            Nrow x ncol dimensional array with type float
        z : ndarray
            Nrow x ncol dimensional array with type float
        directory : str
            The directory where the plot is saved

        Returns
        -------
        fig, ax
            a matplotlib.pyplot figure with associated matplotlib.pyplot axes

        """
        #matplotlib.rc('font', size=20)
        xf = xvalues * 1e6
        yf = yvalues * 1e6
        zf = zvalues * 1e6
        plt.imshow(zf, cmap = 'viridis', aspect = 'auto') # cividis for paper
        ax = plt.gca()
        ax.set_axis_off()
        plt.tight_layout()
        plt.savefig(directory + '/' + 'Original_image.png', dpi = 100)
        plt.close()
    
    def read_image(self):
        """Reads image 
        
        """ 
        path_and_filename = self.input_path_and_filename.get()
        if path_and_filename.endswith(".txt"):
            try:
                # set format of txt file -> set number of header lines
                row, col, ncol, nrow = self.format_file(path_and_filename, self.hlines)
                x_values, y_values, z_values = self.get_values(row, col, ncol, nrow, self.directory,
                                                               path_and_filename)
                self.plot_afmimg(x_values, y_values, z_values, self.directory)
                # normalise z_values
                zmin = np.min(z_values)
                znorm = []
                for zv in z_values:
                    znorm.append(zv - zmin)
                path = self.directory + '/Original_image.png'
                # Shows image in window
                # Initialises the class AFMimg
                self.afmimg = AFMimg(x_values, y_values, np.asarray(znorm), path_and_filename, self.directory)
                # Sets width, height and resolution of image
                self.imgh = (np.max(self.afmimg.yvalues) - np.min(self.afmimg.yvalues))*1e6
                self.imgw = (np.max(self.afmimg.xvalues) - np.min(self.afmimg.xvalues))*1e6
                self.imgrh = self.afmimg.yvalues.shape[0] 
                self.imgrw = self.afmimg.xvalues.shape[1]
                # Initialises propAFMimg object
                self.pafmimg = propAFMimg(self.afmimg.xvalues, self.afmimg.yvalues, self.afmimg.zvalues,
                                          self.afmimg.filename, self.afmimg.directory, self.imgh, self.imgw,
                                          self.imgrh, self.imgrw, 0)
                # Initialises class contAFMimg
                self.cafmimg = contAFMimg(self.afmimg.xvalues, self.afmimg.yvalues, self.afmimg.zvalues,
                                          self.afmimg.filename, self.afmimg.directory, self.pafmimg,
                                          [], [], [], [], [], [], [], [], [], []) 
                self.mimg = self.afmimg
                self.pimg = self.pafmimg
                self.cimg = self.cafmimg
                # Normalises zvalues
                self.cimg.img_gr = normalise_zvalues(self.afmimg.zvalues)
                # Display image
                from PIL import Image, ImageTk
                img = Image.open(path)
                self.raw_img = ImageTk.PhotoImage(img)
                self.rimg_label = tk.Label(self.rawimg, image=self.raw_img)
                self.rimg_label.grid(row=0, column=0)
                # sets variable for cell detection
                self.read_done = False
                # enables threshold tab
                self.tab_parent.tab(self.thresimg, state="normal")
                # Determines possible threshold value
                try:
                    if self.thres.get() == "":
                        self.thres.insert(0, int(filters.threshold_otsu(self.cimg.img_gr)))
                    else:
                        self.thres.delete(0, END)
                        self.thres.insert(0, int(filters.threshold_otsu(self.cimg.img_gr)))
                except AttributeError:
                    self.thres.config(state=DISABLED)
            except:
                messagebox.showerror(title="Error!",
                                          message=("Unfortunately, the input file could not be read correctly, " +
                                                   "making logging error details impossible. Please check the " +
                                                   "chosen file type. If you used one of sample text files, " +
                                                   "please set the number of header lines to '3'. If this was " +
                                                   "not the case, check the number of header lines in your file. " +
                                                   "If these steps do not solve your problem, please contact us " +
                                                   "{c} and we will try to solve this " +
                                                   "issue.").format(c=self.contact))
        else:
            try:
                from PIL import Image, ImageEnhance
                img = Image.open(path_and_filename)
                enh = ImageEnhance.Contrast(img.convert('L'))
                img_enh = enh.enhance(3)
                imgw, imgh = img.size
                if imgw > 512 or imgh > 512:
                    if imgw > imgh:
                        ratio = 512 / imgw
                    else:
                        ratio = 512 / imgh
                elif imgw < 512 or imgh < 512:
                    if imgw > imgh:
                        ratio = 512 / imgw
                    else:
                        ratio = 512 / imgh
                else:
                    ratio = 1
                img_orig = img.resize((int(imgw * ratio), int(imgh * ratio)))
                imgnew = img_enh.resize((int(imgw * ratio), int(imgh * ratio)))
                imgres = cv2.fastNlMeansDenoising(np.asarray(imgnew),10,10,7,21)
                try:
                    channel = imgres.shape[2]
                    img_grey = cv2.cvtColor(np.asarray(img_orig), cv2.COLOR_BGR2GRAY)
                    imgres = cv2.cvtColor(imgres, cv2.COLOR_BGR2GRAY)
                except IndexError:
                    imgres = imgres
                    img_grey = imgres
                # Initialise the class LMimg
                self.lmimg = LMimg(np.asarray(img_orig), np.asarray(img_grey), imgres, path_and_filename,
                                   self.directory)
                # Sets width, height and resolution of image
                self.imgh = 90 
                self.imgw = 90
                self.imgrh = self.lmimg.values.shape[0] 
                self.imgrw = self.lmimg.values.shape[1]
                self.plmimg = propLMimg(self.lmimg.orig, self.lmimg.values, self.lmimg.val_enh,
                                        self.lmimg.filename, self.lmimg.directory, self.imgh, self.imgw,
                                        self.imgrh, self.imgrw, 0)
                self.clmimg = contLMimg(self.lmimg.orig, self.lmimg.values, self.lmimg.val_enh,
                                        self.lmimg.filename, self.lmimg.directory, self.plmimg,
                                        [], [], [], [], [], [], [], [], [], []) 
                self.mimg = self.lmimg
                self.pimg = self.plmimg
                self.cimg = self.clmimg
                # Display image
                from PIL import Image, ImageTk
                self.raw_img = ImageTk.PhotoImage(img_orig)
                self.rimg_label = tk.Label(self.read_image_Frame, image=self.raw_img)
                self.rimg_label.grid(row=1, column=0)
                # sets variable for cell detection
                self.read_done = False
                # enables cell detection tab
                self.tab_parent.tab(self.selst, state="normal")
                self.selst_par = 'normal'
            except:
                self.messagebox.showerror(title="Error!",
                                          message=("Unfortunately, the input file could not be read correctly, " +
                                                   "making logging error details impossible."))
        
    #---------------------------------------------------------------Threshold
    
    def get_thres_entry(self):
        """Gets the manually entered threshold value and applies it to the image
        
        """
        if self.var_meth == "AFM":
            from PIL import ImageTk, Image
            # Calculates thresholded image
            self.img_thr = np.zeros((self.cimg.img_gr.shape[0], self.cimg.img_gr.shape[1]), dtype=np.uint8)
            self.img_thr += np.array((self.cimg.img_gr > int(self.thres.get()))
                                      * 255, np.uint8)
            self.pafmimg.thr = int(self.thres.get())
            self.thres_img = ImageTk.PhotoImage(image=Image.fromarray(self.img_thr))
            self.timg_label = tk.Label(self.thresimg, image=self.thres_img)
            self.timg_label.grid(row=1, column=1)
            self.tab_parent.tab(self.selst, state="normal")
            self.selst_par = 'normal'
            
    #---------------------------------------------------------------Detect cells
    
    def setHC_to_default(self):
        """Setst the parameter for the Hough Circle method to default
        
        """
        if self.HCvar.get() == 1:
            if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
                self.mDist = 28
                self.par1 = 20
                self.par2 = 18
                self.minR = 14
                self.maxR = 30
            elif (self.pimg.imgh > 30 and  self.pimg.imgh < 50
                and self.pimg.imgw > 30 and self.pimg.imgw < 50):
                self.mDist = 50
                self.par1 = 50
                self.par2 = 10
                self.minR = 25
                self.maxR = 50
            elif self.pimg.imgh > 50 and self.pimg.imgw > 50:
                self.mDist = 28
                self.par1 = 10
                self.par2 = 8
                self.minR = 14
                self.maxR = 30                
            else:
                self.mDist = 200
                self.par1 = 50
                self.par2 = 10
                self.minR = 100
                self.maxR = 350
            # Writes parameter values in LineEdits
            self.mDed.delete(0, END)
            self.mDed.insert(0, str(self.mDist))
            self.mDed.config(state=DISABLED)
            self.p1ed.delete(0, END)
            self.p1ed.insert(0, str(self.par1))
            self.p1ed.config(state=DISABLED)
            self.p2ed.delete(0, END)
            self.p2ed.insert(0, str(self.par2))
            self.p2ed.config(state=DISABLED)
            self.miRed.delete(0, END)
            self.miRed.insert(0, str(self.minR))
            self.miRed.config(state=DISABLED)
            self.maRed.delete(0, END)
            self.maRed.insert(0, str(self.maxR)) 
            self.maRed.config(state=DISABLED)
        else:
            self.mDed.config(state=NORMAL)
            self.p1ed.config(state=NORMAL)
            self.p2ed.config(state=NORMAL)
            self.miRed.config(state=NORMAL)
            self.maRed.config(state=NORMAL)
        
        self.status_dc.config(text="Cell detection parameters are set back to default.")
        
    def enh_imageHC(self):
        """Enhances the image and recalculates the cell detection
        
        """
        if self.enhvar.get() == 1:
            self.lmimg.values = self.mimg.val_enh
            self.img_hc = cv2.GaussianBlur(self.lmimg.val_enh, (13, 13), 0)
            if len(self.img_hc.shape) > 2:
                self.img_hc = cv2.cvtColor(self.img_hc, cv2.COLOR_BGR2GRAY)
        else:
            self.lmimg.values = self.mimg.orig
            self.img_hc = cv2.GaussianBlur(self.lmimg.orig, (13, 13), 0)
            if len(self.img_hc.shape) > 2:
                self.img_hc = cv2.cvtColor(self.img_hc, cv2.COLOR_BGR2GRAY)            
        if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
            self.mDist = 28
            self.par1 = 20
            self.par2 = 18
            self.minR = 14
            self.maxR = 30
        elif (self.pimg.imgh > 30 and  self.pimg.imgh < 50
            and self.pimg.imgw > 30 and self.pimg.imgw < 50):
            self.mDist = 50
            self.par1 = 50
            self.par2 = 10
            self.minR = 25
            self.maxR = 50
        elif self.pimg.imgh > 50 and self.pimg.imgw > 50:
            self.mDist = 28
            self.par1 = 10
            self.par2 = 8
            self.minR = 14
            self.maxR = 30                
        else:
            self.mDist = 200
            self.par1 = 50
            self.par2 = 10
            self.minR = 100
            self.maxR = 350
        # Writes parameter values in LineEdits
        self.mDed.delete(0, END)
        self.mDed.insert(0, str(self.mDist))
        self.p1ed.delete(0, END)
        self.p1ed.insert(0, str(self.par1))
        self.p2ed.delete(0, END)
        self.p2ed.insert(0, str(self.par2))
        self.miRed.delete(0, END)
        self.miRed.insert(0, str(self.minR))
        self.maRed.delete(0, END)
        self.maRed.insert(0, str(self.maxR))        
        # HoughCircles
        dc = cv2.HoughCircles(self.img_hc, cv2.HOUGH_GRADIENT, 1, self.mDist, param1 = self.par1,
                              param2 = self.par2, minRadius = self.minR, maxRadius = self.maxR)
        try:
            dc = np.uint16(np.around(dc))

            nimg = cv2.cvtColor(self.img_hc.copy(),cv2.COLOR_GRAY2RGB)
            # format contours
            points = np.array(self.cnt[0])[:,0]
            for c in self.cnt[1:]:
                nc = np.array(c)
                nc = nc.reshape(nc.shape[0],nc.shape[2])
                points = np.concatenate([points, nc])
            # compare number of circle points overlapping with contours
            self.circle_found = []
            for d in dc[0,:]:
                xc,yc,val = skimage.draw.circle_perimeter_aa(d[0],d[1],d[2])
                pp = np.concatenate([np.array([xc]).T,np.array([yc]).T],axis=1)
                dm = scipy.spatial.distance_matrix(points, pp)
                if d[2] < 10:
                    continue
                else:
                    if self.var_meth == 'AFM':
                        if len(np.where(dm==0)[0]) > 10:
                            height, width, channel = nimg.shape
                            if (d[0] + d[2] > width or float(d[0]) - float(d[2]) < 0
                                or d[0] > width or d[0] < 0 or
                                d[1] + d[2] > height or float(d[1]) - float(d[2]) < 0):
                                continue
                            else:
                                self.circle_found.append((d[0], d[1], d[2]))
                    else:
                        height, width, channel = nimg.shape
                        if (d[0] + d[2] > width or float(d[0]) - float(d[2]) < 0
                            or d[0] > width or d[0] < 0 or
                            d[1] + d[2] > height or float(d[1]) - float(d[2]) < 0):
                            continue
                        else:
                            self.circle_found.append((d[0], d[1], d[2]))
            for a, b, c in self.circle_found:
                cv2.circle(nimg, (a, b), c, color =(255, 255, 0), thickness=3)
        except TypeError:
            self.circle_found = []

        # cut out cell image and threshold it (not manually)
        rect_exp = []
        for a, b, c in self.circle_found: # a = xc, b = yc, c = radius
            x0 = a - c * 1
            y0 = b - c * 1
            y1 = b + c * 1
            x1 = a + c * 1
            if x1 - x0 == 0 or y1 - y0 == 0:
                continue
            else:
                rect_exp.append((a, b, c, x0, y0, x1, y1))

        # Resets the coordinates
        self.cimg.rect_exp = rect_exp
        self.label = ['h'] * len(self.cimg.rect_exp)
        self.cimg.coord = []
        if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
            img = self.lmimg.values
            if len(img.shape) > 2:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            img = self.cimg.img_gr
        height, width = img.shape
        # Calculates the extracted cuts
        self.extract_cuts()
        # Plots image with expanded rectangles
        # Display image
        from PIL import Image, ImageTk
        self.findC_img = ImageTk.PhotoImage(image=Image.fromarray(img))
        self.fC_canvas = tk.Canvas(self.selst, width=width, height=height)
        self.fC_canvas.create_image(0, 0, image=self.findC_img, anchor=NW)
        self.fC_canvas.grid(row=0, column=0, rowspan=8)

        for ell in self.circle_found:
            new_e = copy(ell)
            x = int(new_e[0])
            y = int(new_e[1])
            rad = int(new_e[2])
            # create_oval takes upper left corner and lower right corner of bounding rectangle as arguments
            self.fC_canvas.create_oval(x-rad, y-rad, x+rad, y+rad, outline='cyan', width = 3)
        # enables classify tab
        self.tab_parent.tab(self.classify, state="normal")
        
        self.status_dc.config(text="Image is enhanced.")
    
    def get_HC_entry(self):
        """Gets the manually entered values for the Hough Circle method and recalculated the detected
        circles.
        
        """
        self.mDist = int(self.mDed.get())
        self.par1 = int(self.p1ed.get())
        self.par2 = int(self.p2ed.get())
        self.minR = int(self.miRed.get())
        self.maxR = int(self.maRed.get())
        if self.selst_par == 'normal':
            if self.var_meth == 'AFM':
                self.img_hc = self.img_thr
        # Recalculates the detected circles
        # HoughCircles
        dc = cv2.HoughCircles(self.img_hc, cv2.HOUGH_GRADIENT, 1, self.mDist, param1 = self.par1,
                              param2 = self.par2, minRadius = self.minR, maxRadius = self.maxR)
        try:
            dc = np.uint16(np.around(dc))

            nimg = cv2.cvtColor(self.img_hc.copy(),cv2.COLOR_GRAY2RGB)
            # format contours
            points = np.array(self.cnt[0])[:,0]
            for c in self.cnt[1:]:
                nc = np.array(c)
                nc = nc.reshape(nc.shape[0],nc.shape[2])
                points = np.concatenate([points, nc])
            # compare number of circle points overlapping with contours
            self.circle_found = []
            for d in dc[0,:]:
                xc,yc,val = skimage.draw.circle_perimeter_aa(d[0],d[1],d[2])
                pp = np.concatenate([np.array([xc]).T,np.array([yc]).T],axis=1)
                dm = scipy.spatial.distance_matrix(points, pp)
                if d[2] < 10:
                    continue
                else:
                    if self.var_meth == 'AFM':
                        if len(np.where(dm==0)[0]) > 10:
                            height, width, channel = nimg.shape
                            if (d[0] + d[2] > width or float(d[0]) - float(d[2]) < 0
                                or d[0] > width or d[0] < 0 or
                                d[1] + d[2] > height or float(d[1]) - float(d[2]) < 0):
                                continue
                            else:
                                self.circle_found.append((d[0], d[1], d[2]))
                    else:
                        height, width, channel = nimg.shape
                        if (d[0] + d[2] > width or float(d[0]) - float(d[2]) < 0
                            or d[0] > width or d[0] < 0 or
                            d[1] + d[2] > height or float(d[1]) - float(d[2]) < 0):
                            continue
                        else:
                            self.circle_found.append((d[0], d[1], d[2]))
            for a, b, c in self.circle_found:
                cv2.circle(nimg, (a, b), c, color =(255, 255, 0), thickness=3)
        except TypeError:
            self.circle_found = []

        # cut out cell image and threshold it (not manually)
        rect_exp = []
        for a, b, c in self.circle_found: # a = xc, b = yc, c = radius
            x0 = a - c * 1
            y0 = b - c * 1
            y1 = b + c * 1
            x1 = a + c * 1
            if x1 - x0 == 0 or y1 - y0 == 0:
                continue
            else:
                rect_exp.append((a, b, c, x0, y0, x1, y1))

        # Resets the coordinates
        self.cimg.rect_exp = rect_exp
        self.label = ['h'] * len(self.cimg.rect_exp)
        self.cimg.coord = []
        if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
            img = self.mimg.orig
            if len(img.shape) > 2:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            img = self.cimg.img_gr
        height, width = img.shape
        # Calculates the extracted cuts
        self.extract_cuts()
        # Plots image with expanded rectangles
        # Display image
        from PIL import Image, ImageTk
        self.findC_img = ImageTk.PhotoImage(image=Image.fromarray(img))
        self.fC_canvas = tk.Canvas(self.selst, width=width, height=height)
        self.fC_canvas.create_image(0, 0, image=self.findC_img, anchor=NW)
        self.fC_canvas.grid(row=0, column=0, rowspan=6)

        for ell in self.circle_found:
            new_e = copy(ell)
            x = int(new_e[0])
            y = int(new_e[1])
            rad = int(new_e[2])
            # create_oval takes upper left corner and lower right corner of bounding rectangle as arguments
            self.fC_canvas.create_oval(x-rad, y-rad, x+rad, y+rad, outline='cyan', width = 3)  
        # enables classify tab
        self.tab_parent.tab(self.classify, state="normal")
        
        self.status_dc.config(text="Cell detection done.")
    
    def find_cells(self):
        """Finds circular objects in image
        
        """       
        if self.read_done == False:
            self.read_done = True  
            # Sets the parameters for the Hough Circle method
            self.mDl = ttk.Label(self.hough_circ_Frame, text="mDist")
            self.mDl.grid(row=0, column=1)
            self.imDl = ttk.Label(self.hough_circ_Frame, image=self.info_icon)
            self.imDl.grid(row=0, column=2)
            ToolTip(widget = self.imDl, text = "Minimum distance between the centres of two objects.")
            self.mDed = ttk.Entry(self.hough_circ_Frame, width=8)
            self.mDed.grid(row=0, column=3)
            self.p1l = ttk.Label(self.hough_circ_Frame, text="par1")
            self.p1l.grid(row=1, column=1)
            self.ip1l = ttk.Label(self.hough_circ_Frame, image=self.info_icon)
            self.ip1l.grid(row=1, column=2)
            ToolTip(widget = self.ip1l, text = "Measure of how strong the edges of the circles need to be.")
            self.p1ed = ttk.Entry(self.hough_circ_Frame, width=8)
            self.p1ed.grid(row=1, column=3)
            self.p2l = ttk.Label(self.hough_circ_Frame, text="par2")
            self.p2l.grid(row=2, column=1)
            self.ip2l = ttk.Label(self.hough_circ_Frame, image=self.info_icon)
            self.ip2l.grid(row=2, column=2)
            ToolTip(widget = self.ip2l, text = ("Number of edge points that the algorithm has to find to declare" +
                                                " the object a circle."))
            self.p2ed = ttk.Entry(self.hough_circ_Frame, width=8)
            self.p2ed.grid(row=2, column=3)
            self.miRl = ttk.Label(self.hough_circ_Frame, text="minR")
            self.miRl.grid(row=3, column=1)
            self.imiRl = ttk.Label(self.hough_circ_Frame, image=self.info_icon)
            self.imiRl.grid(row=3, column=2)
            ToolTip(widget = self.imiRl, text = "Minimum radius of the detected circles.")
            self.miRed = ttk.Entry(self.hough_circ_Frame, width=8)
            self.miRed.grid(row=3, column=3)
            self.maRl = ttk.Label(self.hough_circ_Frame, text="maxR")
            self.maRl.grid(row=4, column=1)
            self.imaRl = ttk.Label(self.hough_circ_Frame, image=self.info_icon)
            self.imaRl.grid(row=4, column=2)
            ToolTip(widget = self.imaRl, text = "Maximum radius of the detected circles.")
            self.maRed = ttk.Entry(self.hough_circ_Frame, width=8)
            self.maRed.grid(row=4, column=3)
            ttk.Button(self.hough_circ_Frame, text="Change parameters",
                       command=self.get_HC_entry).grid(row=5, column=1, sticky="W", padx=(0, 10))  
            # Enables and disables checkboxes
            if self.meth.get() == "AFM":
                self.enhl.config(foreground='gray')
                self.enh.config(state=DISABLED)
            elif self.meth.get() == "Fluorescence microscopy":
                self.enhl.config(foreground='black')
                self.enh.config(state=NORMAL)
            elif self.meth.get() == "Light microscopy":
                self.enhl.config(foreground='black')
                self.enh.config(state=NORMAL)
            # Hough circles as cell detection
            if self.var_meth == 'AFM':
                values = self.mimg.zvalues
                self.cnt = find_contour_img(values, self.img_thr, self.directory)
                self.img_hc = self.img_thr
            else:
                values = self.mimg.orig
                self.img_hc = cv2.GaussianBlur(self.lmimg.orig, (13, 13), 0)
                if len(self.img_hc.shape) > 2:
                    self.img_hc = cv2.cvtColor(self.img_hc, cv2.COLOR_BGR2GRAY)
                self.cnt = find_contour_img(values, self.img_hc, self.directory)

            if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
                self.mDist = 28
                self.par1 = 20
                self.par2 = 18
                self.minR = 14
                self.maxR = 30
            elif (self.pimg.imgh > 30 and  self.pimg.imgh < 50
                and self.pimg.imgw > 30 and self.pimg.imgw < 50):
                self.mDist = 50
                self.par1 = 50
                self.par2 = 10
                self.minR = 25
                self.maxR = 50
            elif self.pimg.imgh > 50 and self.pimg.imgw > 50:
                self.mDist = 28
                self.par1 = 10
                self.par2 = 8
                self.minR = 14
                self.maxR = 30                
            else:
                self.mDist = 200
                self.par1 = 50
                self.par2 = 10
                self.minR = 100
                self.maxR = 350
            # Writes parameter values in LineEdits
            self.mDed.insert(0, str(self.mDist))
            self.p1ed.insert(0, str(self.par1))
            self.p2ed.insert(0, str(self.par2))
            self.miRed.insert(0, str(self.minR))
            self.maRed.insert(0, str(self.maxR))        
            # HoughCircles
            dc = cv2.HoughCircles(self.img_hc, cv2.HOUGH_GRADIENT, 1, self.mDist, param1 = self.par1,
                                  param2 = self.par2, minRadius = self.minR, maxRadius = self.maxR)
            try:
                dc = np.uint16(np.around(dc))

                nimg = cv2.cvtColor(self.img_hc.copy(),cv2.COLOR_GRAY2RGB)
                # format contours
                points = np.array(self.cnt[0])[:,0]
                for c in self.cnt[1:]:
                    nc = np.array(c)
                    nc = nc.reshape(nc.shape[0],nc.shape[2])
                    points = np.concatenate([points, nc])
                # compare number of circle points overlapping with contours
                self.circle_found = []
                for d in dc[0,:]:
                    xc,yc,val = skimage.draw.circle_perimeter_aa(d[0],d[1],d[2])
                    pp = np.concatenate([np.array([xc]).T,np.array([yc]).T],axis=1)
                    dm = scipy.spatial.distance_matrix(points, pp)
                    if d[2] < 10:
                        continue
                    else:
                        if self.var_meth == 'AFM':
                            if len(np.where(dm==0)[0]) > 10:
                                height, width, channel = nimg.shape
                                if (d[0] + d[2] > width or float(d[0]) - float(d[2]) < 0
                                    or d[0] > width or d[0] < 0 or
                                    d[1] + d[2] > height or float(d[1]) - float(d[2]) < 0):
                                    continue
                                else:
                                    self.circle_found.append((d[0], d[1], d[2]))
                        else:
                            height, width, channel = nimg.shape
                            if (d[0] + d[2] > width or float(d[0]) - float(d[2]) < 0
                                or d[0] > width or d[0] < 0 or
                                d[1] + d[2] > height or float(d[1]) - float(d[2]) < 0):
                                continue
                            else:
                                self.circle_found.append((d[0], d[1], d[2]))
                for a, b, c in self.circle_found:
                    cv2.circle(nimg, (a, b), c, color =(255, 255, 0), thickness=3)
            except TypeError:
                self.circle_found = []

            # Saves bounding rectangles for each cell
            rect_exp = []
            for a, b, c in self.circle_found: # a = xc, b = yc, c = radius
                x0 = a - c * 1
                y0 = b - c * 1
                y1 = b + c * 1
                x1 = a + c * 1
                if x1 - x0 == 0 or y1 - y0 == 0:
                    continue
                else:
                    rect_exp.append((a, b, c, x0, y0, x1, y1))

            # Resets the coordinates
            self.cimg.rect_exp = rect_exp
            self.label = ['h'] * len(self.cimg.rect_exp)
            self.cimg.coord = []
            if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
                img = self.mimg.orig
                if len(img.shape) > 2:
                    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            else:
                img = self.cimg.img_gr
            height, width = img.shape
            # Calculates the extracted cuts
            self.extract_cuts()
            # Plots image with circles
            # Display image
            from PIL import Image, ImageTk
            self.findC_img = ImageTk.PhotoImage(image=Image.fromarray(img))
            self.fC_canvas = tk.Canvas(self.selst, width=width, height=height)
            self.fC_canvas.create_image(0, 0, image=self.findC_img, anchor=NW)
            self.fC_canvas.grid(row=0, column=0, rowspan=6)

            for ell in self.circle_found:
                new_e = copy(ell)
                x = int(new_e[0])
                y = int(new_e[1])
                rad = int(new_e[2])
                # create_oval takes upper left corner and lower right corner of bounding rectangle as arguments
                self.fC_canvas.create_oval(x-rad, y-rad, x+rad, y+rad, outline='cyan', width = 3)
        # enables classify tab
        self.tab_parent.tab(self.classify, state="normal")
                    
    def extract_cuts(self):
        """Extract two characteristic cuts from the image
        
        """
        # Creates new Cell object
        self.cell = Cell([], [], [], self.label, [], [], [], [], [], [])
        if self.var_meth == 'AFM':
            self.cell.calc_cellCnt(self.circle_found, self.cimg.img_gr, self.directory)
        else:
            self.cell.calc_cellCnt(self.circle_found, self.mimg.orig, self.directory)
        self.cell.calc_geomP()
        self.cell.extract_cut(self.circle_found, self.pimg.imgh, self.pimg.imgw, self.pimg.imgrh, self.pimg.imgrw)
                                              
    #---------------------------------------------------------------Classify cells
    def load_NN(self):
        """Loads a pretrained NN
        
        """
        path = self.fdrc
        try:
            if self.var_meth == 'AFM':
                mname = 'NN_AFM'
            elif self.var_meth == 'Light microscopy':
                mname = 'NN_LM'
            elif self.var_meth == 'Fluorescence microscopy':
                mname = 'NN_FM'
            try:
                self.loaded = load_model(path + '/' + 'Neural_networks/' + mname + '_new' + '.h5')
            except OSError:
                self.loaded = load_model(path + '/' + 'Neural_networks/' + mname + '.h5')
        except OSError:
            err_msg = '''Please make sure that the files of the neural network are in the same folder as
            the images you want to evaluate!'''
            messagebox.showerror("Error!", err_msg)
        self.message.config(text = "Network was loaded.")
        # enables predict button
        self.predict["state"] = "normal"
        
    def predict_stages(self):
        """Predicts the category of each cell
        
        """
        self.message.config(text = "To change predictions, please click on the cells.")
        # Normalisation of cuts
        zcut2_norm = []
        for zc in self.cell.zcut2:
            zc_new = []
            for z in zc[0]:
                zmax = max(z)
                zmin = min(z)
                if zmax - zmin == 0:
                    zc_new = np.asarray(z)
                else:
                    z_new = (np.asarray(z) - zmin) / (zmax - zmin)
                zc_new.append(z_new)
            zcut2_norm.append(zc_new)
        self.zcut2_norm = zcut2_norm
        # Reshapes data for NN
        self.nzcut2 = np.asarray(self.zcut2_norm).reshape(np.asarray(self.zcut2_norm).shape[0],
                                                          np.asarray(self.zcut2_norm).shape[2],
                                                          np.asarray(self.zcut2_norm).shape[1])
        # Predict stage of all cell data
        prediction = self.loaded.predict(self.nzcut2)
        # Labels each cell with prediction
        category = []
        for line in prediction:
            category.append(line.tolist().index(np.max(line)))
        self.cell.label = category
        # Makes image with predictions and coloured circles
        # Plots image with circles
        # Displays image
        if self.var_meth == 'Fluorescence microscopy' or self.var_meth == 'Light microscopy':
            img = self.mimg.orig
            if len(img.shape) > 2:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            img = self.cimg.img_gr
        height, width = img.shape
        from PIL import Image, ImageTk
        self.pred_img = ImageTk.PhotoImage(image=Image.fromarray(img))
        self.pS_canvas = tk.Canvas(self.classify, width=width, height=height)
        self.pS_canvas.create_image(0, 0, image=self.pred_img, anchor=NW)
        self.pS_canvas.grid(row=0, column=1, rowspan=6)
        for i in range(0, len(self.cimg.rect_exp)):
            x = self.cimg.rect_exp[i][0]
            y = self.cimg.rect_exp[i][1]
            rad = self.cimg.rect_exp[i][2]
            # create_oval takes upper left corner and lower right corner of bounding rectangle as arguments
            if self.cell.label[i] == 0:
                colour = 'red'#'deepskyblue'
            elif self.cell.label[i] == 1:
                colour = 'blue'
            elif self.cell.label[i] == 2:
                colour = 'yellow'
            elif self.cell.label[i] == 3:
                colour = 'lime'
            self.pS_canvas.create_oval(x-rad, y-rad, x+rad, y+rad, outline=colour, tags=str(i), width=3)   
        # enables change predictions button
        self.cpred["state"] = "normal"
        # enables load new data button
        self.addData["state"] = "normal"
        # enables save button
        self.save["state"] = "normal"
            
    def findCoordinRect(self, boundrect, coord):
        """Finds rectangles around manually chosen coordinates in image

        Parameters
        ----------
        boundrect : ndarray
            1 dimensional array with type int, int, int, int, int, int, int that contains the x-coordinate
            of the circle centre, the y coordinate of the circle centre, the radius of the circle, the 
            x coordinate of the upper left corner of the rectangle, the y coordinate of the upper left corner
            of the rectangle, the x coordinate of the lower right corner, the y coordinate of the lower 
            right corner of the rectangle
        coord : list of tuples
            List of clicked (x, y) coordinates

        Returns
        -------
        array
            an array of tuples with type int, rectangle that contains rectangles around clicked coordinates

        """
        rectChange = []
        for xc,yc in coord:
            i = 0
            for rect in boundrect:
                x = rect[3]
                y = rect[4]
                w = rect[5] - rect[3]
                h = rect[6] - rect[4]
                if xc > x and xc < x+w and yc > y and yc < y+h:
                    rectChange.append((i,rect))
                i += 1
        self.cell.rectChange = rectChange
        
    def mouse_click(self, event):
        """Saves the coordinates on mouse click
        
        """
        # mouse event
        x, y = event.x, event.y
        # Saves coordinates of mouse click
        self.cimg.coord.append((x,y)) 
        self.findCoordinRect(self.cimg.rect_exp, self.cimg.coord)
        # Changes colours
        if len(self.cimg.coord) == 1 and len(self.cell.rectChange) > 0: # ring
            colour = 'blue'
            label = 1
            self.cell.label[self.cell.rectChange[-1][0]] = label
        elif len(self.cimg.coord) == 2 and len(self.cell.rectChange) > 1:
            if (self.cell.rectChange[-1][0] == self.cell.rectChange[-2][0]): # troph
                colour = 'yellow'
                label = 2
                self.cell.label[self.cell.rectChange[-1][0]] = label
            else:
                coord = self.cimg.coord[-1]
                self.cimg.coord = []
                self.cimg.coord.append(coord)
                rectChange = self.cell.rectChange[-1]
                self.cell.rectChange = []
                self.cell.rectChange.append(rectChange)
                colour = 'blue'
                label = 1
                self.cell.label[self.cell.rectChange[-1][0]] = label
        elif len(self.cimg.coord) == 3 and len(self.cell.rectChange) > 1:
            if (self.cell.rectChange[-2][0] == self.cell.rectChange[-1][0]): # schizont
                colour = 'lime'
                label = 3
                self.cell.label[self.cell.rectChange[-1][0]] = label
            else:
                coord = self.cimg.coord[-1]
                self.cimg.coord = []
                self.cimg.coord.append(coord)
                rectChange = self.cell.rectChange[-1]
                self.cell.rectChange = []
                self.cell.rectChange.append(rectChange)
                colour = 'blue'
                label = 1
                self.cell.label[self.cell.rectChange[-1][0]] = label
        elif len(self.cimg.coord) == 4 and len(self.cell.rectChange) > 1:
            if (self.cell.rectChange[-2][0] == self.cell.rectChange[-1][0]): # no cell
                colour = 'magenta'
                label = 4
                self.cell.label[self.cell.rectChange[-1][0]] = label
            else:
                coord = self.cimg.coord[-1]
                self.cimg.coord = []
                self.cimg.coord.append(coord)
                rectChange = self.cell.rectChange[-1]
                self.cell.rectChange = []
                self.cell.rectChange.append(rectChange)
                colour = 'blue'
                label = 1
                self.cell.label[self.cell.rectChange[-1][0]] = label
        elif len(self.cimg.coord) == 5 and len(self.cell.rectChange) > 1:
            if (self.cell.rectChange[-2][0] == self.cell.rectChange[-1][0]): # no cell
                colour = 'red'#'deepskyblue'
                label = 0
                self.cell.label[self.cell.rectChange[-1][0]] = label
            else:
                coord = self.cimg.coord[-1]
                self.cimg.coord = []
                self.cimg.coord.append(coord)
                rectChange = self.cell.rectChange[-1]
                self.cell.rectChange = []
                self.cell.rectChange.append(rectChange)
                colour = 'blue'
                label = 1
                self.cell.label[self.cell.rectChange[-1][0]] = label
        else:
            if len(self.cell.rectChange) > 1:
                if (self.cell.rectChange[-2][0] == self.cell.rectChange[-1][0]): # healthy
                    colour = 'red'#'deepskyblue'
                    label = 0
                    self.label[self.cell.rectChange[-1][0]] = label
                    self.cimg.coord = []
                    rectChange = self.cell.rectChange[-1]
                    self.cell.rectChange = []
                    self.cell.rectChange.append(rectChange) 
                else:
                    coord = self.cimg.coord[-1]
                    self.cimg.coord = []
                    self.cimg.coord.append(coord)
                    rectChange = self.cell.rectChange[-1]
                    self.cell.rectChange = []
                    self.cell.rectChange.append(rectChange)
                    colour = 'blue'
                    label = 1
                    self.cell.label[self.cell.rectChange[-1][0]] = label
            else:
                colour = 'red'#'deepskyblue'
                label = 0
        for r in self.cell.rectChange:
            xr = int(r[1][0])
            yr = int(r[1][1])
            rad = int(r[1][2])
            self.pS_canvas.create_oval(xr-rad, yr-rad, xr+rad, yr+rad, outline=colour, width=3)
            
    # button activates manual corrections
    def change_Circle_predictions(self):
        """Enables the user to manually change the circle colour
        
        """
        self.pS_canvas.bind('<Button 1>', self.mouse_click)   
        
    def addData_NN(self):
        """Adds data to the pre-trained neural network and retrains it with the new data
        
        """
        # if not existing already, creates new directory
        if self.meth.get() == 'Light microscopy':
            meth = 'LM'
        elif self.meth.get() == 'AFM':
            meth = 'AFM'
        else:
            meth = 'FM'
        # Reads all data from the original and new folder and normalises values to range between 0 and 1
        carr_norm = []
        for car in master.cell.zcut2:
            ca_new = []
            for ca in car[0]:
                xmax = max(ca)
                xmin = min(ca)
                if xmax - xmin == 0:
                    c_new = np.asarray(ca)
                else:
                    c_new = (np.asarray(ca) - xmin) / (xmax - xmin)
                ca_new.append(c_new)
            carr_norm.append(ca_new)
        self.cut_read = np.asarray(carr_norm)
        self.label_read = np.asarray(self.cell.label)
        # Saves extracted cross-sections in new folder
        self.dirNN = self.create_newdir(self.fdrc, "Datasets_for_NN_new")
        self.mdirNN = self.create_newdir(self.dirNN ,"Datasets_for_NN_" + meth + "_new")
        self.tdirNN = self.create_newdir(self.mdirNN ,"train_" + meth + "_new")
        self.tldirNN = self.create_newdir(self.mdirNN ,"train_label_" + meth + "_new")
        num = len(os.listdir(self.mdirNN)) - 2
        for i in range(0, len(self.cut_read)):
            num += 1
            values_errout = open(self.tdirNN + '/' + 'zcut2_NN_' + str(num) + '.txt', "w")
            values_errout.write(str(self.cut_read[i]))
            values_errout = open(self.tldirNN + '/' + 'zcut2_NN_y' + str(num) + '.txt', "w")
            values_errout.write(str(self.label_read[i]))
            values_errout.close()
        # Reads old data
        self.cut_train = []
        self.label_train = []
        path = Path(sys.path[0]).parent
        self.NNdrc = str(path.parent)
        input_path = (self.NNdrc + '/' + 'Datasets_for_NN/' + 'Datasets_for_NN_' + meth + '/'
                      + 'train_' + meth)
        try:
            self.input_train = os.listdir(input_path)
            for itrain in self.input_train:
                cs = format_NN_values(itrain, input_path)
                self.cut_train.append(cs)
            input_path = (self.NNdrc + '/' + 'Datasets_for_NN/' + 'Datasets_for_NN_' + meth + '/'
                          + 'train_label_' + meth)
            input_trainl = os.listdir(input_path)
            for itrainl in input_trainl:
                data = open(input_path + '/' + itrainl,'r')
                self.label_train.append(round(float(data.read())))
            self.cut_test = []
            self.label_test = []
            input_path = (self.NNdrc + '/' + 'Datasets_for_NN/' + 'Datasets_for_NN_' + meth + '/'
                          + 'test_' + meth)
            input_test = os.listdir(input_path)
            for itest in input_test:
                cs = format_NN_values(itest, input_path)
                self.cut_test.append(cs)
            input_path = (self.NNdrc + '/' + 'Datasets_for_NN/' + 'Datasets_for_NN_' + meth + '/'
                          + 'test_label_' + meth)
            input_testl = os.listdir(input_path)
            for itestl in input_testl:
                data = open(input_path + '/' + itestl,'r')
                self.label_test.append(round(float(data.read())))
            # Runs NN on data and saves new network
            self.message.config(text="Please wait, network is training...")
            new_model = train_model(self.loaded, self.cut_read, self.label_read, self.cut_train, self.label_train,
                                    self.NNdrc + '/' + 'Malaria_stage_classifier/'
                                    + 'Neural_networks/', "NN_" + self.meth.get() + "_new")
            self.cut_test = np.asarray(self.cut_test)
            self.ncut_test = self.cut_test.reshape(self.cut_test.shape[0], self.cut_test.shape[2],
                                                   self.cut_test.shape[1])
            self.nlabel_test = to_categorical(self.label_test, num_classes=4)
            self.scores = new_model.evaluate(self.ncut_test, self.nlabel_test, verbose=0)
            self.message.config(text="Training is done.")
        except FileNotFoundError:
            self.downloadNN = tk.Toplevel()
            self.downloadNN.grab_set()
            self.downloadNN.title("Download data for NN")
            v = self.NN_data            
            folder = self.NNdrc
            about = '''Please download the folder 'Dataset_for_NN' to train the neural network and save it to:\n
            {folder}.\n
            You can find it on {v}.'''.format(folder=folder, v=v)
            self.downloadNN.label = ttk.Label(self.downloadNN, text=about).grid(row=0, column=0, columnspan=3,
                                                                                sticky="NWES", padx=15, pady=(5, 0))
            ttk.Button(self.downloadNN, text="Download data",
                       command=lambda url=self.NN_data: open_new(url)).grid(row=1, column=1,
                                                                        padx=(0, 15), pady=(0, 5))
            self.centre(self.downloadNN)
                
    def save_predictions(self):
        """Saves predictions and ratio of cell stages in .csv file
        
        """
        numc = len(self.cell.label)
        h = 0
        r = 0
        t = 0
        s = 0
        for label in self.cell.label:
            if label == 0:
                h += 1
            elif label == 1:
                r += 1
            elif label == 2:
                t += 1
            else:
                s += 1
                
        fieldnames = ['filename', 'tot cells', 'healthy', 'ring', 'trophozoite', 'schizont', 'healthy/tot cells',
                      'ring/tot cells', 'trophozoite/tot cells', 'schizont/tot cells']
        self.var_output_filetype = self.output_filetype.get()
        if self.output_filetype.get() == "txt":
            if self.output_filename != "":
                fsp = self.output_filename.get().split('/')
                filename = (fsp[-1].split('.'))[0]
            else:
                filename = 'cell_diagnosis' + '_' + self.prefix[0]
                
            with open(str(self.drc) + '/' + filename  + '.txt', 'a') as f: # directory
                for field in fieldnames:
                    f.write(field + "\t")
                f.write("\n")
                f.close
            rows = [self.prefix, len(self.cell.label), h, r, t, s, h/numc, r/numc, t/numc, s/numc]
            with open(str(self.drc) + '/' + filename  + '.txt', 'a') as f: # directory
                for r in rows:
                    f.write(str(r) + "\t")          
        else:
            # csv data
            rows = [
                {'filename': self.prefix,
                'tot cells': len(self.cell.label),
                'healthy': h,
                'ring': r,
                'trophozoite': t,
                'schizont': s,
                'healthy/tot cells': h/numc,
                'ring/tot cells': r/numc,
                'trophozoite/tot cells': t/numc,
                'schizont/tot cells': s/numc}
            ]

            if self.output_filename != "":
                fsp = self.output_filename.get().split('/')
                filename = (fsp[-1].split('.'))[0]
            else:
                filename = 'cell_diagnosis' + '_' + self.prefix[0]
            with open(str(self.drc) + '/' + filename  + '.csv', 'w',
                      encoding='UTF8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
        self.message.config(text = "Predictions were saved.")
        # deletes raw values and original image for AFM
        file_path = self.directory                         
        if os.path.exists(file_path):
            shutil.rmtree(file_path)
                        
        self.reload = 1   
        self.save_pred = 1
        # opens a window for the user to decide between new file and closing the window
        self.choose_win()

    #----------------------------------------------------Reloads everything for the next data file
    
    def reset_parameters(self):
        """Resets all global variables before loading a new file
        
        """
        self.filename_label["text"] = "No file selected."
        self.input_type.set("")
        self.input_path_and_filename.set("")
        self.meth.set("")
        self.HCvar.set(0)
        self.enhvar.set(0)
        self.output_filename.set("")
        self.output_filetype.set("csv")
        # disables all tabs
        self.tab_parent.tab(self.rawimg, state="disabled")
        self.tab_parent.tab(self.thresimg, state="disabled")
        self.tab_parent.tab(self.selst, state="disabled")
        self.tab_parent.tab(self.classify, state="disabled")
        # disables all buttons
        self.predict["state"] = "disabled"
        self.cpred["state"] = "disabled"
        self.addData["state"] = "disabled"
        self.save["state"] = "disabled"
        # resets output file
        self.output_filename_entry.delete(0, END)
        self.output_file_label.config(text="Nothing selected yet.")
        # removes text file options
        self.input_type_frames_layout()
        # removes images
        try:
            self.timg_label.config(image='')
            self.fC_canvas.destroy()
            self.pS_canvas.destroy()
            self.rimg_label.config(image='')
        except AttributeError: 
            self.fC_canvas.destroy()
            self.pS_canvas.destroy()
            self.rimg_label.config(image='')
        # resets program parameters
        self.read = 0
        self.found = 0
        self.save_pred = 0
        
    def about_program_window(self):
        """Shows window with program information
        
        """
        self.about = tk.Toplevel()
        self.about.grab_set()
        self.about.title("About program")
        v = self.var_version
        about = '''This is version: {v}.\n
        To learn more about the software, see the documentation or the article page.\n
        Copyright (C) 2022  Katharina Preißinger, János Török & István Kézsmárki'''.format(v=v)
        self.about.label = ttk.Label(self.about, text=about).grid(row=0, column=0, columnspan=3, sticky="NWES",
                                                                  padx=15, pady=(5, 0))
        ttk.Button(self.about, text="Article page",
                   command=lambda url=self.article_link: open_new(url)).grid(row=1, column=0,
                                                                             padx=(15, 0), pady=(0, 5))
        ttk.Button(self.about, text="Documentation",
                   command=lambda url=self.doc: open_new(url)).grid(row=1, column=1,
                                                                    padx=(0, 15), pady=(0, 5))
        self.centre(self.about)
        

    def centre(self, win):
        """Centers a tkinter window

        Parameters
        ----------
        win : the root or Toplevel window to center
        
        """
        win.update_idletasks()
        w = win.winfo_width()
        w_root = win.winfo_rootx() - win.winfo_x()
        width = w + 2 * w_root
        h = win.winfo_height()
        h_root = win.winfo_rooty() - win.winfo_y()
        height = h + h_root + w_root
        x = win.winfo_screenwidth() // 2 - width // 2
        y = win.winfo_screenheight() // 2 - height // 2
        win.geometry("{}x{}+{}+{}".format(w, h, x, y))
        win.deiconify()
    
    def load_win(self):
        self.loadnew_window()
    
    def loadnew_window(self):
        """Enables the user to open file location, load a new file or to close the program
        
        """
        win = tk.Toplevel()
        win.grab_set()
        win.title("Predictions not saved")
        def exit(event):
            win.destroy()
        win.bind("<Escape>", exit)

        message = '''You did not save your predictions. Do you want to load a new file?\n
        If not, please select "Close".'''
        tk.Label(win, text=message).grid(row=0, column=0, columnspan=3, sticky="NWES", padx=15, pady=(5, 0))
        ttk.Button(win, text="Load new file", command=self.load_newfile).grid(row=1, column=1, padx=15, pady=5)
        ttk.Button(win, text="Close", command=win.destroy).grid(row=1,column=2, padx=(0, 15), pady=5)

        self.centre(win)
        
    def choose_win(self):
        self.finish_window()        
    
    def finish_window(self):
        """Enables the user to open file location, load a new file or to close the program
        
        """
        win = tk.Toplevel()
        win.grab_set()
        win.title("Load new file or exit application")
        
        def exit(event):
            win.destroy()
        win.bind("<Escape>", exit)
        
        def load_newfile():
            self.tab_parent.select(0)
            self.reset_parameters()
            win.destroy()
        
        def destroy_win():
            self.destroy()
            #win.destroy()

        message = '''Thank you for using this program, please cite us as:
        {}'''.format(self.reference)
        tk.Label(win, text=message).grid(row=0, column=0, columnspan=3, sticky="NWES", padx=15, pady=(5, 0))
        ttk.Button(win, text="Open file location", command=self.open_filelocation).grid(row=1, column=0,
                                                                                        padx=(15, 0), pady=5)
        ttk.Button(win, text="Load new file", command=load_newfile).grid(row=1, column=1, padx=15, pady=5)
        ttk.Button(win, text="Close program", command=destroy_win).grid(row=1,column=2, padx=(0, 15), pady=5)

        self.centre(win)
        
    def open_filelocation(self):
        """Opens file location
        
        """
        directory = self.var_output_filename[:self.var_output_filename.rfind("/")]
        open_new("file://" + directory)
        
        
    def log_window(self, traceback):
        win = tk.Toplevel()
        win.grab_set()
        win.title("Saving error...")
        def exit(event):
            win.destroy()
        win.bind("<Escape>", exit)

        tk.Label(win, text=message).grid(row=0, column=0, columnspan=2, sticky="NWES", padx=15, pady=(5, 0))
        ttk.Button(win, text="Close", command=win.destroy).grid(row=1, column=0, padx=15, pady=5)
        ttk.Button(win, text="Save log file...",
                   command=lambda traceback=traceback: self.save_log_file(traceback)).grid(row=1,column=1,
                                                                                           padx=(0, 15), pady=5)

        self.centre(win)


    def log_error(self, traceback=None):
        """Traces error and saves details in file
        
        """
        log_filepath = asksaveasfilename(initialdir = get_path(""), title = "Save log file as...",
                                         filetypes = (("Text files","*.txt"),("All files","*.*")))

        log_file = open(log_filepath + ".txt","w") 
        L = [
            "------------------------------Traceback details-----------------------",
            "{}".format(traceback),
            "--------------------------------Meta info-----------------------------",
            "OS: {}".format(sys.platform),
            "Software version: {}".format(self.var_version),
            "--------------------------------Runtime specs-------------------------",
            "input_path_and_filename = \"{}\"".format(self.var_input_path_and_filename),
            "output_filename = \"{}\"".format(self.var_output_filename),
            "output_filetype = \"{}\"".format(self.var_output_filetype),

            "input_type = \"{}\"".format(self.var_input_type),

            "------------------------------Input File Dataframe-----------------------"]  

        log_file.writelines("\n".join(L) + "\n") 
        log_file.close()

    def save_log_file(self, traceback):
        """Saves log file
        
        """
        self.destroy()
        self.log_error(traceback)
        error_saved_msg = ("The details of your error message have been saved!\n\n We greatly appreciate" +
                           " your help!\n\n Please send us this file at {c} and we will try to solve this" +
                           " issue.").format(c=self.contact, e=self.contact)
        messagebox.showinfo(title = "File saved!", message=error_saved_msg)

    def open_log_window(traceback):
        """Opens log window
        
        """
        self.destroy()
        self.log_window(traceback)
        
    def error_window(self, error_msg, traceback=None):
        """Opens error window with message
        
        """
        win = tk.Toplevel()
        win.grab_set()
        win.title("Error!")
        def exit(event):
            win.destroy()
        win.bind("<Escape>", exit)

        message = ('''Fatal error!
        Error Message: {}

        For more information, ''' +
                   '''please click on the \"Error Details\" button below.''').format(error_msg)
        ttk.Label(win, text=message).grid(row=0, column=0, columnspan=2, sticky="NWES", padx=15, pady=(5, 0))
        ttk.Button(win, text="Close", command=win.destroy).grid(row=1, column=0, padx=15, pady=5)
        ttk.Button(win, text="Error Details",
                   command=lambda traceback=traceback: self.open_log_window(traceback)).grid(row=1,column=1,
                                                                                             padx=(0, 15), pady=5)

        self.centre(win)
    
    def exit(self, event):
        win.destroy()
        win.bind("<Escape>", exit)
        v = self.var_version
        message = '''This is version: {v}.
        To learn more about the software, see the article page.
        Copyright (C) 2022  Katharina Preißinger, János Török & István Kézsmárki'''.format(v=v)
        ttk.Label(win, text=message).grid(row=0, column=0, columnspan=3, sticky="NWES", padx=15, pady=5)
        ttk.Button(win, text="Article page",
                   command=lambda url=self.article_link: open_new(url)).grid(row=1, column=0,
                                                                             padx=(15, 0), pady=(0, 5))
        ttk.Button(win, text="Software page",
                   command=lambda url=self.software_page: open_new(url)).grid(row=1, column=1, padx=15,
                                                                              pady=(0, 5))
        ttk.Button(win, text="Github repository",
                   command=lambda url=self.github_repository: open_new(url)).grid(row=1, column=2,
                                                                                  padx=(0, 15), pady=(0, 5))
        self.centre(win)
        
if __name__ == "__main__":        
    master = CellDet()
    master.mainloop()